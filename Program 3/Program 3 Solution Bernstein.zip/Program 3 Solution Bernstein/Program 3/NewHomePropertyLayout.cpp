//NewHomePropertyLayout.cpp - Calculates and displays the property layout for a new home construction
//Created by Preston Bernstein on 2/12/2014

#include <iostream>
#include <string>
#define _USE_MATH_DEFINES
#include <math.h>
using namespace std;

int main()
{
	//declare variables
	string userName = "";
	double propertyLength = 0.0;
	double propertyWidth = 0.0;
	double houseLength = 0.0;
	double houseWidth = 0.0;
	const double COST_OF_SOD_PER_SQUARE_FOOT = 1.39;
	double propertyArea = 0.0;
	double houseArea = 0.0;
	double maximumDiameterOfPond = 0.0;
	double pondDiameter = 0.0;
	double pondDepth = 0.0;
	double radius = 0.0;
	double pondArea = 0.0;
	double areaCoveredInSod = 0.0;
	double costOfSod = 0.0;
	double volumeOfPond = 0.0;
	double waterAmountInPond = 0.0;
	const double GALLON_OF_WATER = 19.25;

	//determine username, propertyLength and propertyWidth
	cout << "Hello. Welcome to the New Home Property Layout program. May I have your first name, please?";
	cin >> userName;
	cout << "OK, " << userName << ", now, in feet, tell me how long the property is from front to back.";
	cin >> propertyLength;
	cout << "OK, " << userName << ", now, in feet, tell me how wide the property is from side to side.";
	cin >> propertyWidth;

	//calculate propertyArea
	propertyArea = propertyLength * propertyWidth;

	//determine houseLength and houseWidth
	cout << "OK, " << userName << ", now, in feet, tell me how long the house is from front to back.";
	cin >> houseLength;
	cout << "OK, " << userName << ", now, in feet, tell me how wide the house is from side to side.";
	cin >> houseWidth;

	//calculate houseArea
	houseArea = houseLength * houseWidth;

	//calculate maximumDiameterOfPond
	maximumDiameterOfPond = (propertyWidth) * .85;

	//determine pondDiameter and pondDepth
	cout << "Alright, " << 
		userName << 
		". For the size of your property, you can have a pond diameter of up to " <<
		maximumDiameterOfPond <<
		" in feet installed. You can have a pond smaller than this installed, but not larger.";
	cout << " So, " << 
		userName <<
		", knowing this, how big of a diameter in feet do you want your pond to have?";
	cin >> pondDiameter;
	cout << "Excellent, " << userName << ". Also, in feet, how deep do you want your pond to be?";
	cin >> pondDepth;

	//calculate radius pondArea
	radius = pondDiameter / 2;
	pondArea = M_PI * pow(radius, 2);

	//calculate areaCoveredInSod and costOfSod
	areaCoveredInSod = propertyArea - houseArea - pondArea;
	costOfSod = areaCoveredInSod * COST_OF_SOD_PER_SQUARE_FOOT;

	//calculate the volumeOfPond and waterAmountInPond
	volumeOfPond = pondArea * pondDepth;
	waterAmountInPond = volumeOfPond / GALLON_OF_WATER;

	//display every value that the user inputted, the total square footage of the entire property, the total square footage of the house, the total square footage of the pond, the square footage and total cost of sod, and the number of gallons of water needed to fill the pond to the rim.
	cout << "OK, " << userName <<
		" all finished! The dimensions of the property is " << propertyLength << " feet x " << propertyWidth <<
		" feet. The dimensions of the house is " << houseLength << " feet x " << houseWidth <<
		" feet. The diameter of the pond is " << pondDiameter << " feet. The depth of the pond is " << pondDepth <<
		" feet. The total square footage of the property is " << propertyArea << " square feet. The total square footage of the house is " <<
		houseArea << " square feet. The total square footage of the pond is " << pondArea << " square feet. The square footage and total cost of the sod is " <<
		areaCoveredInSod << " square feet and $" << costOfSod << ". Finally, the number of gallons of water needed to fill the pond to the rim is " <<
		waterAmountInPond << " gallons. Thank you for using this program, and goodbye!" << endl;

	system("pause");
	return 0;
}	//end of main function